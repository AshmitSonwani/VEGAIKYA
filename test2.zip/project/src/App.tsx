import React from 'react';
import { Sparkles } from 'lucide-react';
import { ImageButton } from './components/ImageButton';

function App() {
  const cards = [
    {
      imageUrl: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4",
      title: "Cyber Development",
      description: "Next-gen solutions for tomorrow's challenges"
    },
    {
      imageUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f",
      title: "Digital Innovation",
      description: "Pushing the boundaries of possibility"
    },
    {
      imageUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475",
      title: "Tech Future",
      description: "Embracing the digital revolution"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900">
      {/* Animated background */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-20" />

      <div className="relative">
        {/* Header */}
        <header className="flex items-center justify-between px-8 py-6">
          <div className="flex items-center gap-2">
            <Sparkles className="h-8 w-8 text-cyan-400" />
            <span className="text-2xl font-bold text-white">CyberVision</span>
          </div>
          <nav>
            <ul className="flex gap-8 text-gray-300">
              <li className="cursor-pointer hover:text-cyan-400">About</li>
              <li className="cursor-pointer hover:text-cyan-400">Services</li>
              <li className="cursor-pointer hover:text-cyan-400">Contact</li>
            </ul>
          </nav>
        </header>

        {/* Main Content */}
        <main className="px-8 py-16">
          <div className="mb-16 text-center">
            <h1 className="mb-4 text-5xl font-bold tracking-tight text-white">
              <span className="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
                Future Forward
              </span>
            </h1>
            <p className="mx-auto max-w-2xl text-lg text-gray-300">
              Experience the next generation of digital innovation with our cutting-edge solutions
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-8">
            {cards.map((card, index) => (
              <ImageButton
                key={index}
                imageUrl={card.imageUrl}
                title={card.title}
                description={card.description}
              />
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;