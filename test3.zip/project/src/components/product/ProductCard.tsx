import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Heart } from 'lucide-react';
import { buttonHover, fadeInUp } from '../animations/variants';

interface ProductCardProps {
  imageUrl: string;
  name: string;
  price: string;
  description: string;
}

export function ProductCard({ imageUrl, name, price, description }: ProductCardProps) {
  const [isHovered, setIsHovered] = React.useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -5 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="relative group w-[300px]"
    >
      <div className="overflow-hidden rounded-xl bg-white shadow-xl">
        <div className="relative h-[400px]">
          <motion.img
            src={imageUrl}
            alt={name}
            className="h-full w-full object-cover"
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 0.6, ease: [0.43, 0.13, 0.23, 0.96] }}
          />
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: isHovered ? 1 : 0 }}
            className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent"
          />
          
          <AnimatePresence>
            {isHovered && (
              <>
                <motion.button
                  variants={buttonHover}
                  initial="rest"
                  whileHover="hover"
                  whileTap="tap"
                  className="absolute top-4 right-4 bg-white/90 p-2 rounded-full shadow-lg"
                >
                  <Heart className="w-5 h-5 text-gray-800" />
                </motion.button>

                <motion.div
                  variants={fadeInUp}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                  className="absolute bottom-4 left-0 right-0 px-4"
                >
                  <motion.button
                    variants={buttonHover}
                    initial="rest"
                    whileHover="hover"
                    whileTap="tap"
                    className="w-full bg-white text-black py-2 rounded-full font-medium flex items-center justify-center gap-2 shadow-lg"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    Add to Cart
                  </motion.button>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
        <motion.div 
          className="p-4"
          variants={fadeInUp}
          initial="initial"
          animate="animate"
        >
          <h3 className="text-lg font-semibold text-gray-800">{name}</h3>
          <motion.p 
            className="text-cyan-600 font-medium mt-1"
            whileHover={{ scale: 1.05 }}
          >
            {price}
          </motion.p>
          <p className="text-gray-600 text-sm mt-2">{description}</p>
        </motion.div>
      </div>
    </motion.div>
  );
}